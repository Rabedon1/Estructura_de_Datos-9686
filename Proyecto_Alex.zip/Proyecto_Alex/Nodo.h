#ifndef NODO_H_INCLUDED
#define NODO_H_INCLUDED
#include "Persona.h"
#include "Auto.h"

class Nodo {
public:
    Persona<std::string>* persona;
    Auto* autoObj;
    Nodo* prev;
    Nodo* next;

    Nodo(Persona<std::string>* persona, Auto* autoObj);
    ~Nodo();
};



#endif // NODO_H_INCLUDED
