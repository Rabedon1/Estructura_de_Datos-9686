#include "Menu.h"

int main() {
    Menu menu;
    menu.mostrarMenu();
    return 0;
}
